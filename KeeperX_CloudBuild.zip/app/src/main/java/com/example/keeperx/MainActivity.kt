package com.example.keeperx

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101216)
private val Panel = Color(0xFF1B2028)
private val Accent = Color(0xFF79E0C3)
private val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KeeperXApp() }
    }
}

@Composable
fun KeeperXApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("keeperx", Context.MODE_PRIVATE) }
    val assets = listOf("USD", "EUR", "TON", "GRAM")
    val balances = remember {
        mutableStateMapOf<String, String>().apply {
            assets.forEach { put(it, prefs.getString(it, "0.00") ?: "0.00") }
        }
    }
    var selected by remember { mutableStateOf("Wallet") }
    var secret by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("100") }
    var currency by remember { mutableStateOf("USD") }
    var lastSettingsTap by remember { mutableLongStateOf(0L) }
    var history by remember { mutableStateOf(prefs.getString("history", "No transactions yet") ?: "No transactions yet") }

    fun persist() {
        prefs.edit().apply {
            assets.forEach { putString(it, balances[it] ?: "0") }
            putString("history", history)
            apply()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Wallet", "Swap", "Activity", "Settings").forEach { tab ->
                        val icon = when (tab) {
                            "Wallet" -> Icons.Default.AccountBalanceWallet
                            "Swap" -> Icons.Default.SwapHoriz
                            "Activity" -> Icons.Default.History
                            else -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = {
                                if (tab == "Settings") {
                                    val now = System.currentTimeMillis()
                                    if (now - lastSettingsTap < 650) secret = !secret
                                    lastSettingsTap = now
                                }
                                selected = tab
                            },
                            icon = { Icon(icon, contentDescription = tab) },
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("KEEPER X", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Accent)
                        Spacer(Modifier.weight(1f))
                        Text("DEMO WALLET", color = Muted, fontSize = 11.sp)
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(22.dp)
                    ) {
                        Text(when (selected) {
                            "Wallet" -> "Total balance"
                            "Swap" -> "Demo swap"
                            "Activity" -> "Activity"
                            else -> "Settings"
                        }, color = Muted)
                        Spacer(Modifier.height(8.dp))
                        Text("$${"%.2f".format((balances["USD"] ?: "0").toDoubleOrNull() ?: 0.0)}",
                            fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Text("Virtual funds only • No real assets", color = Muted, fontSize = 12.sp)
                    }
                }
                if (selected == "Wallet") {
                    item { Text("Your assets", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                    items(assets.size) { i ->
                        val asset = assets[i]
                        Row(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(asset, color = Accent, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text(balances[asset] ?: "0.00", fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else if (selected == "Settings") {
                    item {
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
                            Text("Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Keeper X demo wallet", color = Muted)
                            Text("All balances are stored locally on this device.", color = Muted)
                        }
                    }
                    if (secret) {
                        item {
                            Column(Modifier.fillMaxWidth().background(Color(0xFF263A37), RoundedCornerShape(18.dp)).padding(18.dp)) {
                                Text("Secret demo panel", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("Add virtual funds", color = Muted)
                                Spacer(Modifier.height(12.dp))
                                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount") })
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    assets.forEach { a ->
                                        FilterChip(selected = currency == a, onClick = { currency = a }, label = { Text(a) })
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = {
                                    val add = amount.toDoubleOrNull()
                                    if (add != null && add > 0) {
                                        val old = balances[currency]?.toDoubleOrNull() ?: 0.0
                                        balances[currency] = "%.2f".format(old + add)
                                        history = "Added $amount $currency (virtual)"
                                        persist()
                                    }
                                }) { Text("Add virtual funds") }
                            }
                        }
                    }
                } else if (selected == "Activity") {
                    item {
                        Text(history, color = Muted, modifier = Modifier.fillMaxWidth()
                            .background(Panel, RoundedCornerShape(16.dp)).padding(18.dp))
                    }
                } else {
                    item {
                        Text("Swap is a visual demo only. No exchange or blockchain transaction is performed.",
                            color = Muted, modifier = Modifier.fillMaxWidth()
                                .background(Panel, RoundedCornerShape(16.dp)).padding(18.dp))
                    }
                }
            }
        }
    }
}
